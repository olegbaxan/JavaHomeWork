import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private http: HttpClient) { }


  getAll(): Observable<any> {
    return this.http.get('/api/rest/person');
  }
  getById(id:number): Observable<any> {
    console.log("ID-ul:"+id)
    return this.http.get('/api/rest/person/'+id);

  }
  deletePerson(id:number){
    return  this.http.delete('/api/rest/person?id='+id);
  }
  createPerson(person:any){
    return  this.http.post('/api/rest/person',person);
  }
  editPerson(person:any){
    return  this.http.put('/api/rest/person',person);
  }



  showTodayDate() {
    return new Date();
  }
}
