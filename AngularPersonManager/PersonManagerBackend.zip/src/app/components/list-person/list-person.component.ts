import {Component, Injectable, OnInit, Output} from '@angular/core';
import {PersonService} from '../../services/person.service';
import {HeaderComponent} from '../header/header.component';
import {EditPersonComponent} from '../edit-person/edit-person.component'



@Component({
  selector: 'app-list-person',
  templateUrl: './list-person.component.html',
  styleUrls: ['./list-person.component.css']
})
@Injectable({providedIn:EditPersonComponent})
export class ListPersonComponent implements OnInit {

  persons: any
  selectedUser:any

  constructor(private personService: PersonService) {
  }

  ngOnInit(): void {
    this.retrievePersons();
  }

  deletePerson(id:number){
    this.personService.deletePerson(id)
      .subscribe( () => { this.persons.splice(id, 1);}
        ,(error) => {
          console.error(error);
        });
  }
  retrievePersons(): void {
    this.personService.getAll()
      .subscribe((data) => {
          this.persons = data;
          console.log(data);
        },
        (error) => {
          console.error(error);
        });
  }

    // RowSelected(u:any){
    //   this.selectedUser=u;
    //   console.log(("Seleted User: "+this.selectedUser));
      // EditPersonComponent.getPersonData(this.selectedUser);
      // declare variable in component.

      // EditPersonComponent.getPersonData(this.selectedUser);
    // }

}
